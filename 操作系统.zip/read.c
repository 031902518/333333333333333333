#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <error.h>
#define SHM_SIZE     1024
union semun {
    int val;
    struct semid_ds* buf;
    unsigned short* array;
    struct seminfo* buf_info;
    void* pad;
};
int creatsem(const char* pathname, int proj_id, int members, int init_val)
{
    key_t msgkey;
    int index, sid;
    union semun semopts;
    if ((msgkey = ftok(pathname, proj_id)) == -1) {
        perror("ftok error!\n");
        return -1;
    }
    if ((sid = semget(msgkey, members, IPC_CREAT | 0666)) == -1) {
        perror("semget call failed.\n");
        return -1;
    }
    semopts.val = init_val;
    for (index = 0; index < members; index++) {
        semctl(sid, index, SETVAL, semopts);
    }
    return sid;
}

int opensem(const char* pathname, int proj_id)
{
    key_t msgkey;
    int sid;

    if ((msgkey = ftok(pathname, proj_id)) == -1) {
        perror("ftok error!\n");
        return -1;
    }

    if ((sid = semget(msgkey, 0, 0666)) == -1) {
        perror("open semget call failed.\n");
        return -1;
    }
    return sid;
}

int sem_p(int semid, int index)
{
    struct sembuf sbuf = { 0, -1, IPC_NOWAIT };
    if (index < 0) {
        perror("index of array cannot equals a minus value!\n");
        return -1;
    }
    sbuf.sem_num = index;
    if (semop(semid, &sbuf, 1) == -1) {
        perror("A wrong operation to semaphore occurred!\n");
        return -1;
    }
    return 0;
}
int sem_v(int semid, int index)
{
    struct sembuf sbuf = { 0, 1, IPC_NOWAIT };
    if (index < 0) {
        perror("index of array cannot equals a minus value!\n");
        return -1;
    }
    sbuf.sem_num = index;
    if (semop(semid, &sbuf, 1) == -1) {
        perror("A wrong operation to semaphore occurred!\n");
        return -1;
    }
    return 0;
}

int sem_delete(int semid)
{
    return (semctl(semid, 0, IPC_RMID));
}
int wait_sem(int semid, int index)
{
    while (semctl(semid, index, GETVAL, 0) == 0)
    {
        usleep(500);
    }
    return 1;

}
int creatshm(char* pathname, int proj_id, size_t size)
{
    key_t shmkey;
    int sid;

    if ((shmkey = ftok(pathname, proj_id)) == -1) {
        perror("ftok error!\n");
        return -1;
    }
    if ((sid = shmget(shmkey, size, IPC_CREAT | 0666)) == -1) {
        perror("shm call failed!\n");
        return -1;
    }
    return sid;
}
int deleteshm(int sid)
{
    void* p = NULL;
    return (shmctl(sid, IPC_RMID, p));
}
int main(int argc, char** argv)
{
      if(fork()==0)
   {
       int semidread, shmidread;
    char* shmaddrread;
    if ((shmidread = creatshm(".", 57, SHM_SIZE)) == -1)
        return -1;
    if ((shmaddrread = shmat(shmidread, (char*)0, 0)) == (char*)-1) {
        perror("attch shared memory error!\n");
        exit(1);
    }
    if ((semidread = opensem("./", 39)) == -1)
        return -1;
    printf("read start....................\n");
    while (1) {
        
        //printf("read : ");
        wait_sem(semidread, 0);
        if (sem_p(semidread, 0) == -1) 
            break;
        if(strlen(shmaddrread)!=0)
        printf("read:%s", shmaddrread);

        sem_v(semidread, 0);
        usleep(10000);
       
    }
   }
   else{
     int semidwrite, shmidwrite;
        char* myNull="\0";
    char* shmaddrwrite;
    char write_strwrite[SHM_SIZE];
    char* retwrite;
    if ((shmidwrite = creatshm(".", 58, SHM_SIZE)) == -1) 
        return -1;
    if ((shmaddrwrite = shmat(shmidwrite, (char*)0, 0)) == (char*)-1) {
        perror("attch shared memory error!\n");
        exit(1);
    }
    if ((semidwrite = creatsem("./", 38, 1, 1)) == -1)
        return -1;
    while (1) {
        
        wait_sem(semidwrite, 0);
        sem_p(semidwrite, 0);
        //printf("write : ");
        retwrite = fgets(write_strwrite, 1024, stdin);
        if (write_strwrite[0] == '#') 
            break;
        int len = strlen(write_strwrite);
        write_strwrite[len] = '\0';
        //strcpy(shmaddrwrite, write_strwrite);
        int flag;
        scanf("%d",&flag);getchar();
        if(flag==1){
        //printf("You just withdrew the message");
        //getchar();
        strcpy(shmaddrwrite,myNull);
        }
        else         strcpy(shmaddrwrite, write_strwrite);
        sem_v(semidwrite, 0); 
        usleep(1000);
      
    }
   sleep(5);
   }
    return 0;
}
