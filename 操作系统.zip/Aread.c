#include "2-4semshm-.h"
void shmread(int semid,char *shmaddr);
int main(int argc, char** argv)
{
    int semid, shmid;
    char *shmaddr;
        printf("需要连接哪个信箱？请输入：\n");
    	int n;
	scanf("%d",&n);
	getchar();
    if(n==1)
    {
    if((shmid = creatshm(".", 1, SHM_SIZE)) == -1)
        return -1;
    	if((shmaddr = shmat(shmid, (char*)0, 0)) == (char *)-1)
    	{
        perror("attch shared memory error!\n");
        exit(1);
    	}
    }
    if(n==2)
    {
    if((shmid = creatshm(".", 2, SHM_SIZE)) == -1)
        return -1;
    	if((shmaddr = shmat(shmid, (char*)0, 0)) == (char *)-1)
    	{
        perror("attch shared memory error!\n");
        exit(1);
    	}
    }
    printf("已连接到信箱%d,等待读取内容：\n",n);
    if((semid = opensem("./", 38)) == -1)
       return -1;
       
    shmread(semid,shmaddr);
    return 0;
}
void shmread(int semid,char *shmaddr)
{    
        while(1)
	{     
        wait_sem(semid, 0);  //等待信号量可以获取
        sem_p(semid, 0);
        if(shmaddr[0]!='\0')
        printf("read: %s", shmaddr);
        sem_v(semid, 0);
        usleep(10000);
    	}
}
