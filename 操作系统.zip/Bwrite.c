#include "2-4semshm-.h"
void shmwrite(int semid,char *shmaddr,char *write_str,char *ret);
int main(int argc, char** argv)
{
    int semid, shmid;
    char *shmaddr;
    char write_str[SHM_SIZE];
    char *ret;
    	
	printf("需要连接哪个信箱？请输入：\n");
	int n;
	scanf("%d",&n);
	getchar();
    if(n==1)
    {
    if((shmid = creatshm(".", 1, SHM_SIZE)) == -1) //创建或者获取共享内存
        return -1;
    	if((shmaddr = shmat(shmid, (char*)0, 0)) == (char *)-1)
    	{
        perror("attch shared memory error!\n");
        exit(1);
    	}    
    }
    if(n==2)
    {
    if((shmid = creatshm(".", 2, SHM_SIZE)) == -1) //创建或者获取共享内存
        return -1;
    	if((shmaddr = shmat(shmid, (char*)0, 0)) == (char *)-1)
    	{
        perror("attch shared memory error!\n");
        exit(1);
    	}    
    }
    printf("已连接到信箱%d，请输入信息：\n",n);
    if((semid = creatsem("./", 38, 1, 1)) == -1)//创建信号量
        return -1;
    
    shmwrite(semid,shmaddr,write_str,ret);
    sem_delete(semid); //把semid指定的信号集从系统中删除
    //deleteshm(shmid);  //从系统中删除shmid标识的共享内存
    return 0;
}
void shmwrite(int semid,char *shmaddr,char *write_str,char *ret)
{
	while(1)
	{
        wait_sem(semid, 0);//等待信号量可以被获取
        sem_p(semid, 0);  //获取信号量
/***************写共享内存***************************************************/
        ret = fgets(write_str, 1024, stdin);
        int len = strlen(write_str);
        write_str[len] = '\0';
        strcpy(shmaddr, write_str);
        printf("输入1撤回信息，输入其他数允许读取: ");
        int flag;
        scanf("%d",&flag);
        getchar();
        if(flag==1) strcpy(shmaddr,"\0");
        
/****************************************************************************/
        sem_v(semid, 0); //释放信号量
        usleep(1000);  //本进程睡眠.
        }
}
